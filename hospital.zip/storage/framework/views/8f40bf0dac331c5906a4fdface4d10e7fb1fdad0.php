<?php $__env->startSection('content'); ?>
     <h1 class="text-center">LISTA DE DOCTORES</h1>
     <hr>
<div class="container">

    <a id="navbarDropdown" class="nav-link dropdown-toggle float-right" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
        <?php echo e(Auth::user()->name); ?> <i class= "fas fa-user"></i> <span class="caret"></span>
    </a>

    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
           onclick="event.preventDefault();
                         document.getElementById('logout-form').submit();">
            <?php echo e(__('Logout')); ?>

        </a>

        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
            <?php echo csrf_field(); ?>
        </form>
    </div>
    
     <a class="btn btn-primary mb-3" href="<?php echo e(route('doctores.create')); ?>">Crear Doctor</a>
     <a class="btn btn-primary mb-3 float-right" href="<?php echo e(url('doctores.show')); ?>">Imprimir</a>
  <?php if($message = Session::get('success')): ?>
      <div class="alert alert-success">
      <p><?php echo e($message); ?></p>
      </div>
  <?php endif; ?>


     <table class="table table-striped">
  <thead class="table-primary">
    <tr>
      <th scope="col">#</th>
      <th scope="col">Nombre</th>
      <th scope="col">Especialidad</th>
      <th scope="col">Teléfono</th>
      <th class="text-center" colspan="2" scope="col">Acciones</th>
    </tr>
  </thead>
  <tbody>
  <?php $__currentLoopData = $doctores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e($doctor->id); ?></th>
      <td><?php echo e($doctor->nombre); ?></td>
      <td><?php echo e($doctor->especialidad); ?></td>
      <td><?php echo e($doctor->telefono); ?></td> 
      
      <td><a class="btn btn-info" href="<?php echo e(route('doctores.edit',$doctor->id)); ?>"><i class="far fa-edit"></i></a></td>
      <td><a class="btn btn-danger" data-toggle="modal" data-target="#confirmarBorrar-<?php echo e($doctor->id); ?>"><i class="fas fa-trash-alt"></i></a>
    </td>
    </tr>
    <?php echo $__env->make('doctores.confirmarBorrar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
  </table>
  <?php echo e($doctores->links()); ?>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('doctores.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>