<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
    <title>LISTADO</title>
</head>
<body>
    <div class="row mb-2">
        <h1 class="text-center">LISTADO DE DOCTORES</h1>
        <img class="float-right" width="50" src="<?php echo e(asset('images/img.png')); ?> " alt="">
    </div>
    <table class="table table-striped">
        <thead class="table-primary">
          <tr>
            <th scope="col">#</th>
            <th scope="col">Nombre</th>
            <th scope="col">Especialidad</th>
            <th scope="col">Telefono</th>

          </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $doctores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <th scope="row"><?php echo e($doctor->id); ?></th>
            <td><?php echo e($doctor->nombre); ?></td>
            <td><?php echo e($doctor->especialidad); ?></td>
            <td><?php echo e($doctor->telefono); ?></td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        </table>
</body>
</html>