<?php $__env->startSection('content'); ?>
   <h1 class="text-center mt-2">Agregar Doctor</h1>
   <hr>
<!-- Special version of Bootstrap that only affects content wrapped in .bootstrap-iso -->
<link rel="stylesheet" href="https://formden.com/static/cdn/bootstrap-iso.css" /> 

<!-- Inline CSS based on choices in "Settings" tab -->
<style>.bootstrap-iso .formden_header h2, .bootstrap-iso .formden_header p, .bootstrap-iso form{font-family: Arial, Helvetica, sans-serif; color: black}.bootstrap-iso form button, .bootstrap-iso form button:hover{color: white !important;} .asteriskField{color: red;}</style>
<div class="container">

<?php if(count($errors) > 0): ?>
 <div class="alert alert-danger"> 
    <strong>Whoops!</strong> Algunos campos son requeridos
           <ul>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><?php echo e($error); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </ul>
 </div>
<?php endif; ?>



<!-- HTML Form (wrapped in a .bootstrap-iso div) -->
<div class="bootstrap-iso">
 <div class="container-fluid">
  <div class="row">
   <div class="col-md-6 col-sm-6 col-xs-12">
    <form action=<?php echo e(route('doctores.store')); ?> method="post">
    <?php echo csrf_field(); ?>
    
     <div class="form-group ">
      <label class="control-label requiredField" for="nombre">
       Nombre
       <span class="asteriskField">
        *
       </span>
      </label>
      <input class="form-control" id="nombre"  name="nombre" value ="<?php echo e(old('nombre')); ?>" placeholder="Insertar el nombre" type="text"/>
     </div>
     <div class="form-group ">
      <label class="control-label requiredField" for="especialidad">
        Especialidad
       <span class="asteriskField">
        *
       </span>
      </label>
      <input class="form-control" id="especialidad" name="especialidad" value ="<?php echo e(old('especialidad')); ?>" placeholder="Inserta la especialidad" type="text"/>
     </div>
     <div class="form-group ">
      <label class="control-label requiredField" for="telefono">
       Telefono
       <span class="asteriskField">
        *
       </span>
      </label>
      <input maxlength="12"  class="form-control" id="telefono"  name="telefono" value ="<?php echo e(old('telefono')); ?>" placeholder="Inserta el telefono" type="text"/>
     </div>
       <button class="btn btn-primary "  type="submit">
        Agregar
       </button>
         <a class="btn btn-success float-right" href="<?php echo e(route('doctores.index')); ?>">Regresar</a>
       </button>
      </div>
     </div>
    </form>
   </div>


   <div class="col-md-4">
   <img  class="img-fluid" width="300" src="<?php echo e(asset('images/img.png')); ?>" alt="20">
   </div>
  </div>
 </div>
</div>

</div




<?php $__env->stopSection(); ?>
<?php echo $__env->make('doctores.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>